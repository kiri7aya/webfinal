document.addEventListener('DOMContentLoaded', () => {
    const registrationForm = document.getElementById('registrationForm');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const loginFormContent = document.getElementById('loginFormContent');
    const showLogin = document.getElementById('showLogin');
    const showRegister = document.getElementById('showRegister');

    // Toggle between login and registration forms
    showLogin.addEventListener('click', () => {
        registrationForm.classList.add('d-none');
        loginForm.classList.remove('d-none');
    });

    showRegister.addEventListener('click', () => {
        loginForm.classList.add('d-none');
        registrationForm.classList.remove('d-none');
    });

    // Handle registration
    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = document.getElementById('registerUsername').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;

        const users = JSON.parse(localStorage.getItem('users')) || [];
        if (users.some(user => user.username === username)) {
            alert('Username already exists.');
        } else {
            users.push({ username, email, password });
            localStorage.setItem('users', JSON.stringify(users));
            alert('Registration successful! Please login.');
            registrationForm.classList.add('d-none');
            loginForm.classList.remove('d-none');
        }
    });

    // Handle login
    loginFormContent.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;

        const users = JSON.parse(localStorage.getItem('users')) || [];
        const user = users.find(user => user.username === username && user.password === password);

        if (user) {
            localStorage.setItem('loggedInUser', JSON.stringify(user));
            window.location.href = 'home.html';
        } else {
            alert('Invalid username or password.');
        }
    });
});
