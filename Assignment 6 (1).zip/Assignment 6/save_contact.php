<?php
// Define the path to the text file
$file = 'messages.txt';

// Get the form data sent via POST
$data = json_decode(file_get_contents('php://input'), true);

if ($data) {
    // Format the message to save in the file
    $message = "Name: " . $data['name'] . "\n";
    $message .= "Email: " . $data['email'] . "\n";
    $message .= "Message: " . $data['message'] . "\n";
    $message .= "--------------------------\n";

    // Append the message to the file
    file_put_contents($file, $message, FILE_APPEND);

    // Send a success response
    http_response_code(200);
    echo json_encode(["status" => "success", "message" => "Message saved successfully."]);
} else {
    // Send an error response if data is missing
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Failed to save message."]);
}
?>
