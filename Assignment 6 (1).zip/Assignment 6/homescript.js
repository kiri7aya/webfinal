document.addEventListener('DOMContentLoaded', () => {
    const navLoginProfile = document.getElementById('navLoginProfile');
    const user = JSON.parse(localStorage.getItem('loggedInUser')); // Получаем данные о вошедшем пользователе

    if (user) {
        // Если пользователь вошел, меняем на "Profile"
        navLoginProfile.href = 'profile.html';
        navLoginProfile.setAttribute('aria-label', 'Profile');
        navLoginProfile.innerHTML = `
            <i class="bi bi-person"></i>
        `;
    } else {
        // Если пользователь не вошел, оставляем ссылку на "Login"
        navLoginProfile.href = 'login.html';
        navLoginProfile.setAttribute('aria-label', 'Login');
        navLoginProfile.innerHTML = `
            <i class="bi bi-person"></i>
        `;
    }
});





// Map functionality
function initMap() {
    const map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 51.169392, lng: 71.449074 },
        zoom: 10,
    });

    const flowerShops = [
        { name: "Jard Mega Silkway" , lat: 51.090885, lng: 71.398741 },
        { name: "Jard Keruen City", lat: 51.128732, lng: 71.421928 },
        { name: "Jard Khan Shatyr", lat: 51.128327, lng: 71.403919 },
    ];

    flowerShops.forEach(shop => {
        const marker = new google.maps.Marker({
            position: { lat: shop.lat, lng: shop.lng },
            map,
            title: shop.name,
        });

        const infoWindow = new google.maps.InfoWindow({
            content: `<b>${shop.name}</b><br>Beautiful flowers available here!`,
        });

        marker.addListener("click", () => {
            infoWindow.open(map, marker);
        });
    });
}




document.getElementById('toggleMapButton').addEventListener('click', function () {
    const mapElement = document.getElementById('map');
    const isMapVisible = mapElement.style.display === 'block';
    if (isMapVisible) {
        this.textContent = 'Loading...';
        setTimeout(() =>{
            mapElement.style.display = 'none';
            this.textContent = 'Show Our Location';
        }, 2000)
    } else {
        this.textContent = 'Loading...';
        setTimeout(() =>{
            mapElement.style.display = 'block';
            this.textContent = 'Hide Map';
        }, 2000)

    }
});

// Rating functionality
document.querySelectorAll('#stars i').forEach(star => {
    star.addEventListener('click', function() {
        const rating = this.getAttribute('data-rating');
        document.querySelectorAll('#stars i').forEach((s, index) => {
            s.classList.toggle('text-warning', index < rating);
        });
        document.getElementById('ratingMessage').textContent = `You rated us ${rating} out of 5`;
    });
});

// Callback function to handle form submission response
function handleFormSubmission(response) {
    const successMessage = document.getElementById('successMessage');
    if (response.ok) {
        successMessage.style.display = 'block'; // Show success message
        document.getElementById('contactForm').reset(); // Clear the form
        setTimeout(() => {
            successMessage.style.display = 'none';
        }, 2000)
    } else {
        successMessage.textContent = 'There was an error. Please try again.';
        successMessage.classList.replace('alert-success', 'alert-danger');
        successMessage.style.display = 'block';
        setTimeout(() => {
            successMessage.style.display = 'none';
        }, 2000)
    }
}

// Asynchronous form submission using fetch
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    const formData = new FormData(this);
    const data = Object.fromEntries(formData.entries()); // Convert formData to JSON-compatible object

    fetch('save_contact.php', { // Point to the PHP script
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => handleFormSubmission(response)) // Call the callback function
    .catch(error => {
        console.error('Error:', error);
        handleFormSubmission({ ok: false }); // Handle error in callback function
    });
});



document.addEventListener('DOMContentLoaded', () => {
    const infoBlocks = document.querySelectorAll('.info-block');

    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in-view');
                }
            });
        },
        { threshold: 0.3 } // Trigger when 30% of the block is visible
    );

    infoBlocks.forEach(block => observer.observe(block));
});



document.addEventListener('DOMContentLoaded', () => {
    const openQuizButton = document.getElementById('openQuizButton');
    const quizResult = document.getElementById('quizResult');
    const scoreElement = document.getElementById('score');
    const feedbackMessage = document.getElementById('feedbackMessage');

    // Show Quiz Modal
    openQuizButton.addEventListener('click', () => {
        $('#quizModal').modal('show'); // Use Bootstrap's modal functionality
    });

    // Quiz Submission Logic
    const quizForm = document.getElementById('quizForm');
    quizForm.addEventListener('submit', (e) => {
        e.preventDefault();

        let score = 0;
        const formData = new FormData(quizForm);

        // Check answers
        formData.forEach((value) => {
            if (value === 'correct') score++;
        });

        // Display result
        scoreElement.textContent = score;

        // Feedback message
        if (score === 7) {
            feedbackMessage.textContent = "Amazing! You're a flower expert!";
        } else if (score >= 4) {
            feedbackMessage.textContent = "Good job! You know quite a bit about flowers.";
        } else {
            feedbackMessage.textContent = "Keep learning! Flowers are fascinating.";
        }

        quizResult.style.display = 'block';
    });
});

document.addEventListener('DOMContentLoaded', () => {
    // Data for the chart
    const flowerData = [
        { name: 'Roses', y: 40 },
        { name: 'Tulips', y: 20 },
        { name: 'Lilies', y: 15 },
        { name: 'Orchids', y: 10 },
        { name: 'Sunflowers', y: 15 },
    ];

    // Initialize Highcharts
    Highcharts.chart('flowerChart', {
        chart: {
            type: 'pie'
        },
        title: {
            text: 'Popularity of Flower Categories'
        },
        subtitle: {
            text: 'Based on sales data for the current year'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
            point: {
                valueSuffix: '%'
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                }
            }
        },
        series: [{
            name: 'Flowers',
            colorByPoint: true,
            data: flowerData
        }]
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const timelineItems = document.querySelectorAll('.timeline-content');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('in-view');
            }
        });
    }, { threshold: 0.3 }); // Trigger animation when 30% of the element is visible

    timelineItems.forEach((item) => observer.observe(item));
});

document.addEventListener("DOMContentLoaded", function () {
    const promoCarousel = document.querySelector('#promoCarousel');
    const speedSlider = document.querySelector('#carouselSpeed');
    let autoplaySpeed = 3000; // Default 3 seconds

    // Initialize Bootstrap carousel with auto-play
    $(promoCarousel).carousel({
        interval: autoplaySpeed,
        ride: "carousel"
    });

    // Update speed dynamically
    speedSlider.addEventListener("input", function () {
        const sliderValue = speedSlider.value; // 1 (slow) to 10 (fast)
        autoplaySpeed = 1000 + (10 - sliderValue) * 300; // Adjust time in ms (1 to 4 seconds)
        $(promoCarousel).carousel("dispose"); // Stop existing carousel
        $(promoCarousel).carousel({
            interval: autoplaySpeed,
            ride: "carousel"
        });
    });
});
