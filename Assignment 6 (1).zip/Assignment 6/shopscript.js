// Products data with category
const products = [
    { id: 1, name: 'Rose Bouquet', category: 'bouquet', price: 50, image: 'rose.jpg' },
    { id: 2, name: 'Tulip Bouquet', category: 'bouquet', price: 40, image: 'tulip.jpg' },
    { id: 3, name: 'Lily Bouquet', category: 'bouquet', price: 60, image: 'lily.jpg' },
    { id: 4, name: 'Sunflower Bouquet', category: 'plant', price: 36, image: 'sunflower.jpg' },
    { id: 5, name: 'Orchid Bouquet', category: 'plant', price: 70, image: 'orchid.jpg' },
    { id: 6, name: 'Peonies Bouquet', category: 'bouquet', price: 64, image: 'peonies.jpg' }
];

// Cart functionality
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Add product to cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId); // Find product by ID
    const existingItem = cart.find(item => item.id === productId); // Check if product is already in cart

    if (existingItem) {
        // If product is already in cart, increase quantity
        existingItem.quantity++;
    } else {
        // Otherwise, add new product to cart with quantity 1
        cart.push({ ...product, quantity: 1 });
    }

    saveCart(); // Save updated cart to localStorage
    updateCart(); // Update cart display
    showNotification(); // Show success notification
}

// Update cart display
function updateCart() {
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');

    if (cartItems && cartTotal) {
        cartItems.innerHTML = ''; // Clear current cart items display
        let total = 0;

        // Iterate over cart and render each product
        cart.forEach(item => {
            const itemTotal = item.price * item.quantity; // Calculate item total price
            total += itemTotal; // Add to total

            const li = document.createElement('li');
            li.className = 'list-group-item';
            li.innerHTML = `
                ${item.name} - $${item.price} x ${item.quantity} = $${itemTotal.toFixed(2)}
                <button class="btn btn-sm btn-danger float-right" onclick="removeFromCart(${item.id})">Remove</button>
            `;
            cartItems.appendChild(li); // Add item to cart display
        });

        cartTotal.textContent = total.toFixed(2); // Update total price display
    }
}

// Remove product from cart
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId); // Remove item by ID
    saveCart(); // Save updated cart to localStorage
    updateCart(); // Update cart display
}

// Save cart to localStorage
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Show notification
function showNotification() {
    $('#notificationModal').modal('show'); // Show Bootstrap modal
    setTimeout(() => {
        $('#notificationModal').modal('hide'); // Hide modal after 1.5 seconds
    }, 1500);
}

// Filtering functionality
const categoryFilter = document.getElementById('categoryFilter');
const priceFilter = document.getElementById('priceFilter');

function filterProducts() {
    const category = categoryFilter.value;
    const priceRange = priceFilter.value;
    let filteredProducts = products;

    if (category !== 'all') {
        filteredProducts = filteredProducts.filter(product => product.category === category);
    }
    if (priceRange !== 'all') {
        const [min, max] = priceRange.split('-').map(Number);
        filteredProducts = filteredProducts.filter(product => product.price >= min && product.price <= max);
    }

    renderProducts(filteredProducts); // Render filtered products
}

// Render products
function renderProducts(productList = products) {
    const container = document.getElementById('productContainer');
    container.innerHTML = ''; // Clear current products display

    productList.forEach(product => {
        const productElement = document.createElement('div');
        productElement.className = 'col-lg-4 col-md-6 mb-4';
        productElement.innerHTML = `
            <div class="card h-100">
                <img class="card-img-top" src="${product.image}" alt="${product.name}">
                <div class="card-body">
                    <h4 class="card-title">${product.name}</h4>
                    <h5>$${product.price.toFixed(2)}</h5>
                    <button class="btn btn-primary" onclick="addToCart(${product.id})">Add to Cart</button>
                </div>
            </div>
        `;
        container.appendChild(productElement); // Add product to display
    });
}

// Add event listeners for filters
if (categoryFilter && priceFilter) {
    categoryFilter.addEventListener('change', filterProducts);
    priceFilter.addEventListener('change', filterProducts);
}

document.addEventListener('DOMContentLoaded', () => {
    const flowerItems = document.querySelectorAll('.flower-item');
    const dropZone = document.querySelector('.drop-zone');
    const dropZoneText = document.getElementById('dropZoneText');
    const bouquetMessage = document.getElementById('bouquetMessage');
    const completeButton = document.getElementById('completeBouquet');
    let bouquet = [];

    flowerItems.forEach(item => {
        item.addEventListener('dragstart', (e) => {
            // Передаем данные: имя и изображение
            e.dataTransfer.setData('flower-name', item.getAttribute('data-name'));
            e.dataTransfer.setData('flower-image', item.querySelector('img').src);
            item.classList.add('dragging');
        });

        item.addEventListener('dragend', () => {
            item.classList.remove('dragging');
        });
    });

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragging');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragging');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragging');

        const flowerName = e.dataTransfer.getData('flower-name');
        const flowerImage = e.dataTransfer.getData('flower-image');

        if (dropZoneText) {
            dropZoneText.style.display = 'none';
        }

        // Проверяем, добавлен ли цветок
        if (flowerName && !bouquet.includes(flowerName)) {
            bouquet.push(flowerName);

            // Создаем блок с изображением цветка
            const flowerElement = document.createElement('div');
            flowerElement.className = 'dropped-flower';
            flowerElement.innerHTML = `
                <img src="${flowerImage}" alt="${flowerName}" class="img-fluid rounded">
                <p>${flowerName}</p>
            `;
            dropZone.appendChild(flowerElement);
        }
    });

    completeButton.addEventListener('click', () => {
        if (bouquet.length > 0) {
            bouquetMessage.textContent = `Вы создали прекрасный букет из: ${bouquet.join(', ')}!`;
        } else {
            bouquetMessage.textContent = `Ваш букет пуст! Перетащите цветы.`;
        }
    });
});

// Initialize page
renderProducts(); // Render all products on page load
updateCart(); // Update cart display on page load
